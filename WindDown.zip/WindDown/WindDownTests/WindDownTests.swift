//
//  WindDownTests.swift
//  WindDownTests
//
//  Created by Lauren Galarza on 11/6/24.
//

import Testing
@testable import WindDown

struct WindDownTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
