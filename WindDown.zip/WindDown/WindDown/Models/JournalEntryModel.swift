//
//  JournalEntryModel.swift
//  WindDown
//
//  Created by Lauren Galarza on 12/9/24.
//
import Foundation
import SwiftUI

struct JournalEntry: Identifiable {
    let id = UUID()
    let date: Date
    let text: String
}
