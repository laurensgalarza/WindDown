//
//  WeatherData.swift
//  WindDown
//
//  Created by Lauren Galarza on 12/8/24.
//

import Foundation

struct WeatherData: Decodable {
    
    let main: Main
    let wind: Wind
    
    
    struct Main: Decodable {
        let temp: Double
        let humidity: Int
        
    }
    
    struct Wind: Decodable {
        let speed: Double
    }
    


    
    
}
