//
//  WindDownApp.swift
//  WindDown
//
//  Created by Lauren Galarza on 11/6/24.
//

import SwiftUI

@main
struct WindDownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
