//
//  InsightsViewModel.swift
//  WindDown
//
//  Created by Lauren Galarza on 12/8/24.


import Foundation
import SwiftUI

class InsightsViewModel: ObservableObject{
    
    @Published var weatherData: WeatherData?
    @Published var errorMessage: String?
    
    
    func getWeather(for city: String){
        
        let apiKey = "b0a3acbcc9a70c3b77daf3c54210c850" //API key from personal account
        let baseURLString = "https://api.openweathermap.org/data/2.5/weather?q=\(city)&units=imperial&appid=\(apiKey)"    //OpenWeather api url

        //handle errors
        //url not valid
        guard let url = URL(string: baseURLString) else {
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        
        URLSession.shared.dataTask(with: request) {
            data, response, error in
            
            if let error = error {
                DispatchQueue.main.async{
                    self.errorMessage = "Error fetching data"
                    
                }
                return
            }
            
            guard data != nil else{
                self.errorMessage = "No Data"
                return
            }
            
            do{
                let decoder = JSONDecoder()
                let decodedData = try decoder.decode(WeatherData.self, from: data!)
                
                DispatchQueue.main.async {
                    
                    self.weatherData = decodedData
                }
                
            }
            catch{
                
                DispatchQueue.main.async{
                    self.errorMessage = "Failed to parse through data"
                }
                
            }
            

            
            
        }.resume()
   
    
        
    }

    func generateInsight() -> String {

        if let temp = weatherData?.main.temp, let humid = weatherData?.main.humidity, let wind = weatherData?.wind.speed {
            
            
            if temp < 20.0 {
                
                return "Cool weather promotes deep, restorative sleep."
                
            }
            
            else if humid <= 30{
                return "Low humidity may cause dryness; consider using a humidifier."
            }


            else if wind < 5 {
                return "A gentle breeze can aid in cooling tonight."
            }
            
            
            else if humid > 30 && humid <= 50{
                return "Humidity is perfect for a restful night's sleep."
            }
            
            
            else if temp >= 20.0 && temp < 60.0 {
                
                return "Enjoy tonight's refreshing, comfortable sleeping conditions."
                
            }
            else if temp >= 60.0 && temp < 80.0{
                
                return "Stay cool tonight with a fan or cool shower."
                        
                        
                }
            
            else if wind >= 5 && wind < 15 {
                return "Windy night ahead; meditative sounds can help relax."
            }
            else if humid > 50 {
                return "High humidity may feel sticky; use a fan."
            }
            
            else if temp >= 80.0{
                
                return "High heat may disrupt sleep; hydrate and stay cool."
                        
                        
                }
            
            else if wind >= 15{
                return "Windy night ahead; meditative sounds can help relax."
            }
      
            
            else {
                return "Weather greatly influences sleep quality and comfort every night."
            }
        }
        else {
            return "Weather greatly influences sleep quality and comfort every night."
        }
        

        
    }
    
}
